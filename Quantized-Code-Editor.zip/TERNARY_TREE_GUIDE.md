# 🌳 Ternary Binary Decision Tree - Visual Guide

## Tree Structure

```
                        ROOT: Assess Complexity
                        (prompt analysis)
                    /           |              \
                  -1            0              +1
               Simple        Medium          Complex
                  |             |               |
                  ▼             ▼               ▼
          ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
          │Local Models?│  │Perf History?│  │Model Capacity│
          └─────────────┘  └─────────────┘  └─────────────┘
           /    |    \       /    |    \       /    |    \
         -1     0    +1    -1     0    +1    -1     0    +1
          │     │     │     │     │     │     │     │     │
          ▼     ▼     ▼     ▼     ▼     ▼     ▼     ▼     ▼
    ┌────────────────────────────────────────────────────────┐
    │               LEAF NODES (MODEL SELECTION)             │
    ├────────────────────────────────────────────────────────┤
    │  qwen    code-  qwen   phi3   qwen   deep-  phi3  qwen  deep- │
    │  2.5     llama  2.5           2.5    seek         2.5   seek  │
    └────────────────────────────────────────────────────────┘
```

## Decision Criteria Details

### Level 1: Complexity Assessment (-1, 0, 1)

```javascript
function assessComplexity(context) {
  let score = 0;
  
  // Word count
  if (wordCount > 50) score++;
  
  // Multi-step indicator
  if (/then|after|next/.test(prompt)) score++;
  
  // Architecture keywords
  if (/design|architect|system/.test(prompt)) score += 2;
  
  // Multi-file indicator
  if (/files|modules|components/.test(prompt)) score++;
  
  // File size
  if (fileSize > 10000) score++;
  
  // Return ternary decision
  if (score >= 4) return +1;  // Complex
  if (score >= 2) return 0;   // Medium
  return -1;                  // Simple
}
```

**Examples:**

| Prompt | Score | Complexity | Branch |
|--------|-------|------------|--------|
| "fix typo in line 42" | 0 | Simple | -1 (left) |
| "refactor this function for better readability" | 2 | Medium | 0 (center) |
| "design microservices architecture with event sourcing and CQRS" | 5 | Complex | +1 (right) |

### Level 2A: Local Model Availability (Simple path)

```javascript
function checkLocalAvailability(context) {
  const available = context.availableModels.filter(m => m.type === 'local');
  const total = ALL_LOCAL_MODELS.length;
  const ratio = available.length / total;
  
  if (ratio >= 0.8) return +1;  // Most available
  if (ratio >= 0.4) return 0;   // Some available
  return -1;                    // Few available
}
```

**Example:**
- 4 out of 4 local models running → +1 → `qwen2.5-coder:14b` (fastest)
- 2 out of 4 local models running → 0 → `codellama:13b` (backup)
- 0 out of 4 local models running → -1 → `gemini-free` (cloud fallback)

### Level 2B: Performance History (Medium path)

```javascript
function checkPerformanceHistory(context) {
  const relevant = history.filter(
    p => p.taskType === context.taskType && 
         p.extension === context.extension
  );
  
  if (relevant.length === 0) return 0; // No history
  
  const avgLatency = average(relevant.map(p => p.latency));
  const successRate = relevant.filter(p => p.success).length / relevant.length;
  
  if (successRate > 0.9 && avgLatency < 2000) return +1;  // Excellent
  if (successRate > 0.7 && avgLatency < 5000) return 0;   // Average
  return -1;                                               // Poor
}
```

**Example:**
- Previous TypeScript tasks: 95% success, 300ms avg → +1 → `deepseek-coder:33b`
- Previous TypeScript tasks: 75% success, 4000ms avg → 0 → `qwen2.5-coder:14b`
- Previous TypeScript tasks: 50% success, 8000ms avg → -1 → `phi3:14b`

### Level 2C: Model Capacity (Complex path)

```javascript
function checkModelCapacity(context) {
  const estimatedTokens = context.prompt.length / 4;
  const highCapModels = context.availableModels.filter(
    m => m.maxTokens >= 8192
  );
  
  if (estimatedTokens > 6000 && highCapModels.length > 0) return +1;  // High
  if (estimatedTokens > 3000) return 0;                                // Medium
  return -1;                                                            // Low
}
```

**Example:**
- 10,000 character prompt (2500 tokens) → 0 → check task type
- 30,000 character prompt (7500 tokens) → +1 → `deepseek-coder:33b` (16K ctx)

## Complete Routing Examples

### Example 1: Simple Syntax Fix

```
User: "fix syntax error in hello.ts"

Step 1: Assess Complexity
  - Word count: 5 (no score)
  - Multi-step: No
  - Architecture: No
  - Multi-file: No
  - Total score: 0
  → Decision: -1 (Simple)

Step 2: Check Local Availability
  - 4/4 Ollama models running
  - Ratio: 1.0
  → Decision: +1 (All available)

Step 3: Select Model
  - Path: ROOT(-1) → LocalAvail(+1)
  → Model: qwen2.5-coder:14b
  
Routing complete: 342ms to solution
```

### Example 2: Complex Architecture Task

```
User: "Design a microservices architecture for e-commerce platform with 
      API gateway, service mesh, event sourcing, and CQRS pattern. Include 
      detailed component diagrams and communication flows."

Step 1: Assess Complexity
  - Word count: 24 (+1)
  - Multi-step: "and" implies steps (+1)
  - Architecture: "microservices", "architecture", "pattern" (+2)
  - Multi-file: "components" (+1)
  - Total score: 5
  → Decision: +1 (Complex)

Step 2: Check Model Capacity
  - Estimated tokens: ~400
  - High capacity models available: yes
  - Prompt complexity requires reasoning
  → Decision: 0 (Medium capacity sufficient)

Step 3: Check Task Type
  - Task: Architecture
  → Decision: +1 (Specialized task)

Step 4: Select Model
  - Path: ROOT(+1) → Capacity(0) → TaskType(+1)
  → Model: deepseek-coder:33b
  
Routing complete: 1247ms to detailed architecture
```

### Example 3: Medium Refactoring with History

```
User: "Refactor this TypeScript class to use dependency injection"

Step 1: Assess Complexity
  - Word count: 8
  - Multi-step: No
  - Architecture: No
  - Multi-file: No
  - File referenced: 350 lines
  - Total score: 1
  → Decision: 0 (Medium)

Step 2: Check Performance History
  - Previous TypeScript refactors:
    - qwen: 87% success, 450ms avg
    - deepseek: 94% success, 520ms avg
    - phi3: 76% success, 800ms avg
  → Decision: +1 (Excellent history)

Step 3: Check Circuit Health
  - All circuits: CLOSED
  → Decision: +1 (Healthy)

Step 4: Select Model
  - Path: ROOT(0) → PerfHist(+1) → CircuitHealth(+1)
  → Model: deepseek-coder:33b
  
Routing complete: 489ms to refactored code
```

## Circuit Breaker Integration

```
┌─────────────────────────────────────────────┐
│  Ternary Tree selects: deepseek-coder:33b  │
└─────────────────────────────────────────────┘
                    │
                    ▼
        ┌───────────────────────┐
        │ Check Circuit Breaker │
        └───────────────────────┘
         /           |            \
    CLOSED       HALF_OPEN        OPEN
       │             │              │
       ▼             ▼              ▼
  Use model    Try model      Use fallback
                    │              │
                    ▼              ▼
             ┌─────────┐    qwen2.5-coder:14b
             │Success? │           │
             └─────────┘           │
              /      \             │
            Yes      No            │
             │        │            │
             ▼        ▼            ▼
          CLOSED    OPEN      (recursive check)
```

## Performance Characteristics

### Time Complexity

```
Linear Selection (old):
  O(n) where n = number of models
  9 models = 9 comparisons worst case

Ternary Tree (new):
  O(log₃ n) where n = number of models
  9 models = 2-3 comparisons worst case

Speedup: 3-4.5x for 9 models
```

### Space Complexity

```
Linear: O(1) - no extra storage
Ternary Tree: O(log n) - recursion stack

Trade-off: Minimal space for significant speed gain
```

### Decision Quality

```
Linear Selection:
  - First match wins
  - No optimization over time
  - Binary yes/no decisions

Ternary Tree:
  - Best match selected
  - Learns from history
  - Nuanced -1/0/+1 decisions
  - Circuit breaker integration

Result: Better model selection = higher success rate
```

## Tuning Guide

### Adjust Complexity Thresholds

```typescript
// In Router.ts, modify assessComplexity()

// More aggressive (prefers complex models)
if (score >= 3) return 1;  // Was: 4
if (score >= 1) return 0;  // Was: 2

// More conservative (prefers simple models)
if (score >= 5) return 1;  // Was: 4
if (score >= 3) return 0;  // Was: 2
```

### Adjust Circuit Breaker

```typescript
// In config
circuitBreakerThreshold: 5,   // Allow more failures
circuitBreakerCooldown: 60000  // Wait longer before retry
```

### Custom Tree

```typescript
// Replace decision tree entirely
const customTree: TernaryNode = {
  condition: (ctx) => {
    // Your custom logic
    if (ctx.prompt.includes('urgent')) return 1;
    if (ctx.prompt.includes('simple')) return -1;
    return 0;
  },
  left: 'fast-model',
  center: 'balanced-model',
  right: 'powerful-model'
};
```

---

**Ternary Binary Trees: Because -1, 0, and 1 are all you need to rule the model routing world.** 🌳⚡
