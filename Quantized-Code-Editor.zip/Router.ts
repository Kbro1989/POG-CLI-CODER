/**
 * Free Model Router with Ternary Binary Decision Tree
 * 
 * Decision tree uses -1/0/1 ternary logic for efficient routing:
 * -1 = Low priority/capability
 *  0 = Medium/fallback
 *  1 = High priority/optimal
 */

import { execSync } from 'child_process';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';
import pino from 'pino';
import type {
  ModelPerformance,
  CircuitBreakerState,
  Result,
  FreeModelConfig,
  TernaryNode,
  RoutingContext,
  TaskType,
  CircuitState,
  ModelType,
  VibeConfig
} from './models.js';
import { CircuitState as CS, TaskType as TT, ModelType as MT } from './models.js';

const logger = pino({ name: 'Router' });

export class FreeModelRouter {
  private readonly performanceDB: string;
  private readonly circuitBreakers: Map<string, CircuitBreakerState> = new Map();
  private readonly FREE_MODELS: ReadonlyArray<FreeModelConfig> = [
    {
      name: 'qwen2.5-coder:14b',
      command: 'ollama run qwen2.5-coder:14b',
      type: MT.Local,
      capabilities: ['code', 'generate', 'debug', 'refactor'],
      maxTokens: 8192,
      temperature: 0.7,
      priority: 90
    },
    {
      name: 'phi3:14b',
      command: 'ollama run phi3:14b',
      type: MT.Local,
      capabilities: ['reason', 'explain', 'architecture'],
      fallback: 'qwen2.5-coder:14b',
      maxTokens: 4096,
      temperature: 0.5,
      priority: 80
    },
    {
      name: 'deepseek-coder:33b',
      command: 'ollama run deepseek-coder:33b',
      type: MT.Local,
      capabilities: ['architecture', 'refactor', 'optimize'],
      fallback: 'qwen2.5-coder:14b',
      maxTokens: 16384,
      temperature: 0.6,
      priority: 95
    },
    {
      name: 'codellama:13b',
      command: 'ollama run codellama:13b',
      type: MT.Local,
      capabilities: ['code', 'generate', 'test'],
      fallback: 'qwen2.5-coder:14b',
      maxTokens: 4096,
      priority: 75
    },
    {
      name: 'gemini-free',
      command: 'gemini',
      type: MT.CloudFree,
      capabilities: ['research', 'plan', 'architecture'],
      maxTokens: 32768,
      priority: 70
    }
  ] as const;

  private readonly decisionTree: TernaryNode;

  constructor(private readonly config: VibeConfig) {
    this.performanceDB = join(config.pogDir, 'free-model-performance.json');
    this.initializeDB();
    this.decisionTree = this.buildDecisionTree();
    logger.info({ pogDir: config.pogDir }, 'Router initialized');
  }

  private initializeDB(): void {
    if (!existsSync(this.performanceDB)) {
      writeFileSync(
        this.performanceDB,
        JSON.stringify({ history: [], version: '1.0.0' }, null, 2)
      );
      logger.debug('Performance database initialized');
    }
  }

  /**
   * Build ternary binary decision tree for routing
   * Tree structure optimizes for:
   * 1. Task complexity (simple -> complex)
   * 2. Model availability (local first)
   * 3. Historical performance
   * 4. Circuit breaker state
   */
  private buildDecisionTree(): TernaryNode {
    return {
      // Root: Check task complexity
      condition: (ctx) => this.assessComplexity(ctx),
      
      // Simple tasks (-1)
      left: {
        condition: (ctx) => this.checkLocalAvailability(ctx),
        left: 'qwen2.5-coder:14b', // No local models
        center: 'codellama:13b', // Some local models
        right: 'qwen2.5-coder:14b' // All local models available
      },
      
      // Medium complexity (0)
      center: {
        condition: (ctx) => this.checkPerformanceHistory(ctx),
        left: {
          condition: (ctx) => this.checkCapabilityMatch(ctx),
          left: 'phi3:14b',
          center: 'qwen2.5-coder:14b',
          right: 'deepseek-coder:33b'
        },
        center: 'qwen2.5-coder:14b',
        right: {
          condition: (ctx) => this.checkCircuitHealth(ctx),
          left: 'qwen2.5-coder:14b', // Fallback
          center: 'phi3:14b',
          right: 'deepseek-coder:33b' // Best performer
        }
      },
      
      // Complex tasks (1)
      right: {
        condition: (ctx) => this.checkModelCapacity(ctx),
        left: 'phi3:14b', // Limited capacity
        center: {
          condition: (ctx) => this.checkTaskType(ctx),
          left: 'qwen2.5-coder:14b', // Code generation
          center: 'phi3:14b', // Reasoning
          right: 'deepseek-coder:33b' // Architecture
        },
        right: 'deepseek-coder:33b' // Full capacity
      }
    };
  }

  /**
   * Traverse ternary decision tree
   */
  private traverseTree(node: TernaryNode, context: RoutingContext): string {
    if (node.modelName) {
      return node.modelName;
    }

    const decision = node.condition(context);
    
    let nextNode: TernaryNode | string | undefined;
    if (decision < 0) {
      nextNode = node.left;
    } else if (decision === 0) {
      nextNode = node.center;
    } else {
      nextNode = node.right;
    }

    if (!nextNode) {
      logger.warn({ decision, context }, 'No path in decision tree, using fallback');
      return 'qwen2.5-coder:14b';
    }

    if (typeof nextNode === 'string') {
      return nextNode;
    }

    return this.traverseTree(nextNode, context);
  }

  /**
   * Assess task complexity: -1 (simple), 0 (medium), 1 (complex)
   */
  private assessComplexity(ctx: RoutingContext): number {
    const promptLength = ctx.prompt.length;
    const wordCount = ctx.prompt.split(/\s+/).length;
    
    // Complex indicators
    const hasMultiStep = /\b(then|after|next|finally|step)\b/i.test(ctx.prompt);
    const hasArchitecture = /\b(design|architect|system|microservice|pattern)\b/i.test(ctx.prompt);
    const hasMultiFile = /\b(files|modules|components|services)\b/i.test(ctx.prompt);
    
    let score = 0;
    if (wordCount > 50) score += 1;
    if (hasMultiStep) score += 1;
    if (hasArchitecture) score += 2;
    if (hasMultiFile) score += 1;
    if (ctx.fileSize && ctx.fileSize > 10000) score += 1;
    
    if (score >= 4) return 1; // Complex
    if (score >= 2) return 0; // Medium
    return -1; // Simple
  }

  /**
   * Check local model availability: -1 (none), 0 (some), 1 (all)
   */
  private checkLocalAvailability(ctx: RoutingContext): number {
    const localModels = ctx.availableModels.filter(m => m.type === MT.Local);
    const totalLocal = this.FREE_MODELS.filter(m => m.type === MT.Local).length;
    
    const ratio = localModels.length / totalLocal;
    
    if (ratio >= 0.8) return 1; // Most available
    if (ratio >= 0.4) return 0; // Some available
    return -1; // Few/none available
  }

  /**
   * Check performance history: -1 (poor), 0 (avg), 1 (good)
   */
  private checkPerformanceHistory(ctx: RoutingContext): number {
    const relevant = ctx.historicalPerformance.filter(
      p => p.taskType === ctx.taskType && p.extension === ctx.extension
    );

    if (relevant.length === 0) return 0; // No history

    const avgLatency = relevant.reduce((sum, p) => sum + p.latency, 0) / relevant.length;
    const successRate = relevant.filter(p => p.success).length / relevant.length;

    if (successRate > 0.9 && avgLatency < 2000) return 1; // Excellent
    if (successRate > 0.7 && avgLatency < 5000) return 0; // Average
    return -1; // Poor
  }

  /**
   * Check capability match: -1 (poor), 0 (partial), 1 (excellent)
   */
  private checkCapabilityMatch(ctx: RoutingContext): number {
    const requiredCaps = this.extractRequiredCapabilities(ctx.taskType);
    
    let bestMatch = -1;
    for (const model of ctx.availableModels) {
      const matchCount = requiredCaps.filter(cap => 
        model.capabilities.includes(cap)
      ).length;
      
      const matchRatio = matchCount / requiredCaps.length;
      if (matchRatio > 0.8) return 1;
      if (matchRatio > 0.5) bestMatch = Math.max(bestMatch, 0);
      else bestMatch = Math.max(bestMatch, -1);
    }
    
    return bestMatch;
  }

  /**
   * Check circuit breaker health: -1 (open), 0 (half-open), 1 (closed)
   */
  private checkCircuitHealth(ctx: RoutingContext): number {
    const states = Array.from(this.circuitBreakers.values());
    
    const openCount = states.filter(s => s.state === CS.Open).length;
    const halfOpenCount = states.filter(s => s.state === CS.HalfOpen).length;
    
    if (openCount === 0 && halfOpenCount === 0) return 1; // All healthy
    if (openCount > states.length / 2) return -1; // Mostly broken
    return 0; // Degraded
  }

  /**
   * Check model capacity: -1 (low), 0 (medium), 1 (high)
   */
  private checkModelCapacity(ctx: RoutingContext): number {
    const estimatedTokens = ctx.prompt.length / 4; // Rough estimate
    
    const highCapModels = ctx.availableModels.filter(
      m => (m.maxTokens ?? 4096) >= 8192
    );
    
    if (estimatedTokens > 6000 && highCapModels.length > 0) return 1;
    if (estimatedTokens > 3000) return 0;
    return -1;
  }

  /**
   * Check task type specificity: -1 (general), 0 (specific), 1 (specialized)
   */
  private checkTaskType(ctx: RoutingContext): number {
    switch (ctx.taskType) {
      case TT.Architecture:
        return 1; // Needs deepseek/phi3
      case TT.Refactor:
      case TT.Debug:
        return 0; // Medium specificity
      case TT.Generate:
      case TT.Syntax:
      default:
        return -1; // General task
    }
  }

  private extractRequiredCapabilities(taskType: TaskType): string[] {
    const capabilityMap: Record<TaskType, string[]> = {
      [TT.Architecture]: ['architecture', 'design', 'reason'],
      [TT.Syntax]: ['code', 'generate'],
      [TT.Refactor]: ['refactor', 'optimize', 'code'],
      [TT.Debug]: ['debug', 'code', 'reason'],
      [TT.Generate]: ['generate', 'code'],
      [TT.Test]: ['test', 'code', 'generate'],
      [TT.Docs]: ['explain', 'reason']
    };

    return capabilityMap[taskType] ?? ['code'];
  }

  /**
   * Main routing method using ternary decision tree
   */
  async route(prompt: string, filePath?: string): Promise<Result<string>> {
    try {
      const taskType = this.classifyTask(prompt);
      const ext = filePath?.split('.').pop() ?? '';
      
      const availableModels = this.getAvailableModels();
      if (availableModels.length === 0) {
        return {
          ok: false,
          error: new Error('No free models available. Install Ollama: https://ollama.ai')
        };
      }

      const historicalPerformance = this.loadPerformanceHistory();
      
      const context: RoutingContext = {
        prompt,
        taskType,
        extension: ext,
        fileSize: filePath ? this.getFileSize(filePath) : undefined,
        complexity: this.assessComplexity({
          prompt,
          taskType,
          extension: ext,
          historicalPerformance,
          availableModels
        }),
        historicalPerformance,
        availableModels
      };

      // Use ternary decision tree
      const selectedModel = this.traverseTree(this.decisionTree, context);
      
      // Apply circuit breaker
      const finalModel = this.applyCircuitBreaker(selectedModel, availableModels);
      
      logger.info({
        task: taskType,
        selected: finalModel,
        complexity: context.complexity
      }, 'Model routed');

      return { ok: true, value: finalModel };
    } catch (error) {
      logger.error({ error }, 'Routing failed');
      return { ok: false, error: error as Error };
    }
  }

  private classifyTask(prompt: string): TaskType {
    const patterns: Record<TaskType, RegExp> = {
      [TT.Architecture]: /\b(design|architect|microservice|system|pattern|structure)\b/i,
      [TT.Syntax]: /\b(fix|syntax|parse|compile|error|lint)\b/i,
      [TT.Refactor]: /\b(refactor|optimize|clean|rewrite|restructure)\b/i,
      [TT.Debug]: /\b(debug|bug|crash|stack|investigate|trace)\b/i,
      [TT.Generate]: /\b(create|generate|build|make|write|implement)\b/i,
      [TT.Test]: /\b(test|spec|assert|verify|validate)\b/i,
      [TT.Docs]: /\b(document|comment|explain|describe)\b/i
    };

    for (const [type, regex] of Object.entries(patterns)) {
      if (regex.test(prompt)) {
        return type as TaskType;
      }
    }

    return TT.Generate; // Default
  }

  private getAvailableModels(): ReadonlyArray<FreeModelConfig> {
    return this.FREE_MODELS.filter(model => {
      if (model.type === MT.Local) {
        try {
          execSync('ollama list', { stdio: 'pipe', timeout: 2000 });
          const models = execSync('ollama list', { encoding: 'utf-8', timeout: 2000 });
          return models.includes(model.name.split(':')[0] ?? '');
        } catch {
          return false;
        }
      }
      
      if (model.type === MT.CloudFree) {
        try {
          const cmd = model.command.split(' ')[0];
          if (!cmd) return false;
          execSync(`command -v ${cmd}`, { stdio: 'pipe', timeout: 1000 });
          return true;
        } catch {
          return false;
        }
      }
      
      return false;
    });
  }

  private getFileSize(filePath: string): number | undefined {
    try {
      const content = readFileSync(filePath, 'utf-8');
      return content.length;
    } catch {
      return undefined;
    }
  }

  private loadPerformanceHistory(): ReadonlyArray<ModelPerformance> {
    try {
      const data = JSON.parse(
        readFileSync(this.performanceDB, 'utf-8')
      ) as { history: ModelPerformance[] };
      return data.history;
    } catch {
      return [];
    }
  }

  private applyCircuitBreaker(
    model: string,
    availableModels: ReadonlyArray<FreeModelConfig>
  ): string {
    const state = this.circuitBreakers.get(model);
    
    if (!state) {
      this.circuitBreakers.set(model, {
        model,
        failures: 0,
        threshold: this.config.circuitBreakerThreshold,
        state: CS.Closed,
        lastFailure: 0,
        cooldownMs: this.config.circuitBreakerCooldown
      });
      return model;
    }

    // Check cooldown for OPEN circuits
    if (state.state === CS.Open && Date.now() - state.lastFailure > state.cooldownMs) {
      state.state = CS.HalfOpen;
      state.failures = 0;
      logger.info({ model }, 'Circuit breaker moved to HALF_OPEN');
    }

    if (state.state === CS.Open) {
      const fallback = this.FREE_MODELS.find(m => m.name === model)?.fallback;
      if (fallback && availableModels.some(m => m.name === fallback)) {
        logger.warn({ model, fallback }, 'Circuit OPEN, using fallback');
        return this.applyCircuitBreaker(fallback, availableModels);
      }
      
      // Last resort: use highest priority available model
      const sorted = [...availableModels].sort((a, b) => b.priority - a.priority);
      const lastResort = sorted[0]?.name ?? 'qwen2.5-coder:14b';
      logger.warn({ model, lastResort }, 'No fallback, using highest priority');
      return lastResort;
    }

    return model;
  }

  recordPerformance(perf: ModelPerformance): void {
    try {
      const data = JSON.parse(
        readFileSync(this.performanceDB, 'utf-8')
      ) as { history: ModelPerformance[]; version: string };
      
      data.history.push(perf);
      
      // Keep only last 10000 records
      if (data.history.length > 10000) {
        data.history = data.history.slice(-10000);
      }
      
      writeFileSync(this.performanceDB, JSON.stringify(data, null, 2));
      logger.debug({ model: perf.model, success: perf.success }, 'Performance recorded');
    } catch (error) {
      logger.error({ error }, 'Failed to record performance');
    }
  }

  recordFailure(model: string): void {
    const state = this.circuitBreakers.get(model);
    
    if (!state) {
      this.circuitBreakers.set(model, {
        model,
        failures: 1,
        threshold: this.config.circuitBreakerThreshold,
        state: CS.Closed,
        lastFailure: Date.now(),
        cooldownMs: this.config.circuitBreakerCooldown
      });
      return;
    }
    
    state.failures++;
    state.lastFailure = Date.now();
    
    if (state.failures >= state.threshold) {
      state.state = CS.Open;
      logger.warn({ model, failures: state.failures }, 'Circuit breaker OPEN');
    }
  }

  recordSuccess(model: string): void {
    const state = this.circuitBreakers.get(model);
    
    if (state?.state === CS.HalfOpen) {
      state.state = CS.Closed;
      state.failures = 0;
      logger.info({ model }, 'Circuit breaker CLOSED after success');
    }
  }

  getCircuitState(model: string): CircuitState {
    return this.circuitBreakers.get(model)?.state ?? CS.Closed;
  }
}
