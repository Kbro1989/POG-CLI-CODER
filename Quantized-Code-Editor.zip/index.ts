#!/usr/bin/env node

/**
 * POG-CODER-VIBE CLI - Terminal-first AI coding interface
 * 
 * Features:
 * - Ternary binary routing (3x faster)
 * - Type-safe error handling
 * - Structured logging
 * - Session management
 * - Real-time VS Code integration
 */

import readline from 'readline';
import { homedir } from 'os';
import { join } from 'path';
import pino from 'pino';
import { ConfigManager } from '../src/utils/config.js';
import { FreeOrchestrator } from '../src/core/Orchestrator.js';
import type { Result } from '../src/core/models.js';

const logger = pino({
  name: 'CLI',
  level: process.env.VIBE_LOG_LEVEL || 'info',
  transport: {
    target: 'pino-pretty',
    options: {
      colorize: true,
      translateTime: 'HH:MM:ss',
      ignore: 'pid,hostname'
    }
  }
});

interface CommandHandler {
  readonly pattern: RegExp;
  readonly description: string;
  readonly handler: (args: string[]) => Promise<void> | void;
}

class VibeCLI {
  private readonly rl: readline.Interface;
  private readonly orchestrator: FreeOrchestrator;
  private readonly configManager: ConfigManager;
  private running = true;

  constructor(projectRoot: string) {
    // Initialize configuration
    this.configManager = new ConfigManager(projectRoot);
    const config = this.configManager.getConfig();

    // Initialize orchestrator
    this.orchestrator = new FreeOrchestrator(config);

    // Create readline interface
    this.rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
      prompt: '🎯 vibe> ',
      terminal: true
    });

    // Setup event listeners
    this.setupEventListeners();

    logger.info({
      projectRoot,
      sessionId: this.orchestrator.getSessionId(),
      wsPort: config.wsPort
    }, 'CLI initialized');
  }

  private setupEventListeners(): void {
    // Orchestrator events
    this.orchestrator.on('intentExecuted', (data) => {
      logger.debug({
        model: data.selectedModel,
        success: data.success,
        executionTime: data.executionTime
      }, 'Intent executed');
    });

    this.orchestrator.on('modelCalled', (data) => {
      console.log(`🤖 Using model: ${data.model}`);
    });

    this.orchestrator.on('executionError', (data) => {
      logger.error({
        error: data.error,
        prompt: data.context.prompt.substring(0, 100)
      }, 'Execution error');
    });

    // Readline events
    this.rl.on('line', async (line) => {
      await this.handleInput(line.trim());
      if (this.running) {
        this.rl.prompt();
      }
    });

    this.rl.on('close', async () => {
      await this.shutdown();
    });

    // Handle Ctrl+C gracefully
    process.on('SIGINT', async () => {
      console.log('\n\n👋 Shutting down gracefully...');
      await this.shutdown();
      process.exit(0);
    });
  }

  async start(): Promise<void> {
    // Initialize orchestrator
    const initResult = await this.orchestrator.initialize();
    if (!initResult.ok) {
      logger.fatal({ error: initResult.error }, 'Failed to initialize orchestrator');
      process.exit(1);
    }

    // Display welcome banner
    this.displayBanner();

    // Start REPL
    this.rl.prompt();
  }

  private displayBanner(): void {
    const config = this.configManager.getConfig();
    const sessionId = this.orchestrator.getSessionId();

    console.clear();
    console.log('🎯 POG-CODER-VIBE v1.0 (Optimized Edition)');
    console.log(`📁 Project: ${config.projectRoot}`);
    console.log(`💾 Session: ${sessionId}`);
    console.log(`🔌 VS Code: ws://localhost:${config.wsPort}`);
    console.log('');
    console.log('Available commands:');
    console.log('  <your intent>    - Execute AI intent with ternary routing');
    console.log('  history          - View intent history');
    console.log('  state            - Show current state');
    console.log('  config           - Show configuration');
    console.log('  help             - Show this help');
    console.log('  exit             - Quit (saves session)');
    console.log('');
  }

  private readonly commands: ReadonlyArray<CommandHandler> = [
    {
      pattern: /^exit$/i,
      description: 'Exit the REPL',
      handler: async () => {
        this.running = false;
        this.rl.close();
      }
    },
    {
      pattern: /^help$/i,
      description: 'Show available commands',
      handler: () => {
        console.log('\n📚 Available Commands:\n');
        for (const cmd of this.commands) {
          console.log(`  ${cmd.description}`);
        }
        console.log('\n💡 Tips:');
        console.log('  - Use natural language for intents');
        console.log('  - Models are automatically selected via ternary routing');
        console.log('  - All operations are type-safe with Result types');
        console.log('');
      }
    },
    {
      pattern: /^history$/i,
      description: 'View intent history',
      handler: () => {
        const history = this.orchestrator.getIntentHistory();
        if (history.length === 0) {
          console.log('No intents executed yet.\n');
          return;
        }

        console.log('\n📊 Intent History:\n');
        const recent = history.slice(-10);
        for (const intent of recent) {
          const status = intent.success ? '✅' : '❌';
          const time = new Date(intent.timestamp).toLocaleTimeString();
          console.log(`${status} [${time}] ${intent.selectedModel}`);
          console.log(`   "${intent.query.substring(0, 60)}..."`);
          console.log(`   Execution time: ${intent.executionTime}ms\n`);
        }
      }
    },
    {
      pattern: /^state$/i,
      description: 'Show current state',
      handler: () => {
        const state = this.orchestrator.getCurrentState();
        console.log('\n🎯 Current State:\n');
        console.log(JSON.stringify(state, null, 2));
        console.log('');
      }
    },
    {
      pattern: /^config$/i,
      description: 'Show configuration',
      handler: () => {
        const config = this.configManager.getConfig();
        console.log('\n⚙️  Configuration:\n');
        console.log(JSON.stringify(config, null, 2));
        console.log('');
      }
    }
  ];

  private async handleInput(input: string): Promise<void> {
    if (!input) {
      return;
    }

    // Check for built-in commands
    for (const cmd of this.commands) {
      if (cmd.pattern.test(input)) {
        await cmd.handler(input.split(/\s+/));
        return;
      }
    }

    // Treat as AI intent
    await this.executeIntent(input);
  }

  private async executeIntent(prompt: string): Promise<void> {
    console.log(''); // Blank line for readability

    try {
      const result = await this.orchestrator.executeIntent(prompt);

      if (!result.ok) {
        console.error(`❌ Error: ${result.error.message}\n`);
        return;
      }

      console.log('✅ Response:\n');
      console.log(result.value);
      console.log('');
    } catch (error) {
      logger.error({ error }, 'Unexpected error');
      console.error(`❌ Unexpected error: ${(error as Error).message}\n`);
    }
  }

  private async shutdown(): Promise<void> {
    logger.info('Shutting down CLI');
    this.running = false;

    await this.orchestrator.cleanup();

    console.log('💾 Session saved');
    console.log(`📊 Total intents: ${this.orchestrator.getIntentHistory().length}`);
    console.log('👋 Goodbye!\n');
  }
}

// Main entry point
async function main(): Promise<void> {
  try {
    const projectRoot = process.cwd();
    const cli = new VibeCLI(projectRoot);
    await cli.start();
  } catch (error) {
    logger.fatal({ error }, 'Fatal error');
    console.error('💥 Fatal error:', (error as Error).message);
    process.exit(1);
  }
}

// Run if executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error) => {
    console.error('Unhandled error:', error);
    process.exit(1);
  });
}

export { VibeCLI };
