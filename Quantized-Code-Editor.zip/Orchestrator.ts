/**
 * Free Orchestrator - Coordinates all subsystems
 * 
 * Responsibilities:
 * - Route intents to best model
 * - Execute model calls
 * - Manage snapshots
 * - Emit events for monitoring
 * - Learn from errors
 */

import { EventEmitter } from 'events';
import { spawn, ChildProcess } from 'child_process';
import pino from 'pino';
import type {
  Result,
  IntentHistory,
  VibeConfig,
  TaskType,
  ModelPerformance
} from './models.js';
import { FreeModelRouter } from './Router.js';

const logger = pino({ name: 'Orchestrator' });

interface ExecutionContext {
  readonly prompt: string;
  readonly filePath?: string;
  readonly sessionId: string;
  readonly startTime: number;
}

interface ModelResponse {
  readonly model: string;
  readonly response: string;
  readonly latency: number;
}

export interface OrchestratorEvents {
  intentExecuted: (data: IntentHistory) => void;
  modelCalled: (data: { model: string; prompt: string }) => void;
  executionError: (data: { error: Error; context: ExecutionContext }) => void;
  snapshotCreated: (data: { snapshotId: string; reason: string }) => void;
}

export declare interface FreeOrchestrator {
  on<K extends keyof OrchestratorEvents>(
    event: K,
    listener: OrchestratorEvents[K]
  ): this;
  emit<K extends keyof OrchestratorEvents>(
    event: K,
    ...args: Parameters<OrchestratorEvents[K]>
  ): boolean;
}

export class FreeOrchestrator extends EventEmitter {
  private readonly router: FreeModelRouter;
  private readonly sessionId: string;
  private readonly intentHistory: IntentHistory[] = [];
  private wsServer?: import('ws').WebSocketServer;

  constructor(private readonly config: VibeConfig) {
    super();
    this.router = new FreeModelRouter(config);
    this.sessionId = this.generateSessionId();
    
    logger.info({
      sessionId: this.sessionId,
      pogDir: config.pogDir
    }, 'Orchestrator initialized');
  }

  private generateSessionId(): string {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 11);
    return `vibe_${timestamp}_${random}`;
  }

  async initialize(): Promise<Result<void>> {
    try {
      await this.setupWebSocket();
      logger.info({ port: this.config.wsPort }, 'WebSocket server started');
      return { ok: true, value: undefined };
    } catch (error) {
      logger.error({ error }, 'Initialization failed');
      return { ok: false, error: error as Error };
    }
  }

  private async setupWebSocket(): Promise<void> {
    const { WebSocketServer } = await import('ws');
    this.wsServer = new WebSocketServer({ port: this.config.wsPort });
    
    this.wsServer.on('connection', (ws) => {
      logger.debug('Client connected');
      
      // Send initial state
      ws.send(JSON.stringify({
        type: 'state',
        data: this.getCurrentState()
      }));

      // Forward events
      this.on('intentExecuted', (data) => {
        ws.send(JSON.stringify({ type: 'intentExecuted', data }));
      });
    });

    this.wsServer.on('error', (error) => {
      logger.error({ error }, 'WebSocket error');
    });
  }

  /**
   * Execute user intent with ternary routing
   */
  async executeIntent(
    prompt: string,
    filePath?: string
  ): Promise<Result<string>> {
    const context: ExecutionContext = {
      prompt,
      filePath,
      sessionId: this.sessionId,
      startTime: Date.now()
    };

    logger.info({
      prompt: prompt.substring(0, 100),
      filePath
    }, 'Executing intent');

    // Step 1: Route to best model
    const routeResult = await this.router.route(prompt, filePath);
    if (!routeResult.ok) {
      logger.error({ error: routeResult.error }, 'Routing failed');
      return routeResult;
    }

    const selectedModel = routeResult.value;
    logger.info({ model: selectedModel }, 'Model selected');

    this.emit('modelCalled', { model: selectedModel, prompt });

    // Step 2: Call model
    const callResult = await this.callModel(selectedModel, prompt);
    if (!callResult.ok) {
      this.router.recordFailure(selectedModel);
      this.recordIntent(context, selectedModel, false, 0);
      this.emit('executionError', { error: callResult.error, context });
      return callResult;
    }

    const { model, response, latency } = callResult.value;
    this.router.recordSuccess(model);

    // Step 3: Record performance
    const taskType = this.classifyTaskType(prompt);
    const performance: ModelPerformance = {
      model,
      taskType,
      extension: filePath?.split('.').pop() ?? '',
      latency,
      success: true,
      timestamp: Date.now(),
      isFree: true
    };
    this.router.recordPerformance(performance);

    // Step 4: Record intent
    const executionTime = Date.now() - context.startTime;
    this.recordIntent(context, model, true, executionTime);

    logger.info({
      model,
      latency,
      executionTime
    }, 'Intent executed successfully');

    return { ok: true, value: response };
  }

  /**
   * Call free model (Ollama or CLI tools)
   */
  private async callModel(
    model: string,
    prompt: string
  ): Promise<Result<ModelResponse>> {
    const startTime = Date.now();

    try {
      // Ollama models
      if (model.includes(':') || model.includes('ollama')) {
        const response = await this.callOllama(model, prompt);
        const latency = Date.now() - startTime;
        return {
          ok: true,
          value: { model, response, latency }
        };
      }

      // Gemini CLI
      if (model === 'gemini-free') {
        const response = await this.callCLI('gemini', [prompt]);
        const latency = Date.now() - startTime;
        return {
          ok: true,
          value: { model, response, latency }
        };
      }

      // Unknown model
      return {
        ok: false,
        error: new Error(`Unknown model type: ${model}`)
      };
    } catch (error) {
      return {
        ok: false,
        error: error as Error
      };
    }
  }

  /**
   * Call Ollama model
   */
  private callOllama(model: string, prompt: string): Promise<string> {
    return new Promise((resolve, reject) => {
      const proc = spawn('ollama', ['run', model], {
        stdio: ['pipe', 'pipe', 'pipe']
      });

      let output = '';
      let errorOutput = '';

      proc.stdout.on('data', (data) => {
        output += data.toString();
      });

      proc.stderr.on('data', (data) => {
        errorOutput += data.toString();
      });

      proc.on('close', (code) => {
        if (code === 0) {
          resolve(output.trim());
        } else {
          reject(new Error(`Ollama failed: ${errorOutput || 'Unknown error'}`));
        }
      });

      proc.on('error', (error) => {
        reject(error);
      });

      // Send prompt
      proc.stdin.write(prompt);
      proc.stdin.end();

      // Timeout after 60 seconds
      setTimeout(() => {
        proc.kill();
        reject(new Error('Model call timeout (60s)'));
      }, 60000);
    });
  }

  /**
   * Call generic CLI tool
   */
  private callCLI(command: string, args: string[]): Promise<string> {
    return new Promise((resolve, reject) => {
      const proc = spawn(command, args, {
        stdio: ['pipe', 'pipe', 'pipe']
      });

      let output = '';
      let errorOutput = '';

      proc.stdout.on('data', (data) => {
        output += data.toString();
      });

      proc.stderr.on('data', (data) => {
        errorOutput += data.toString();
      });

      proc.on('close', (code) => {
        if (code === 0) {
          resolve(output.trim());
        } else {
          reject(new Error(`${command} failed: ${errorOutput}`));
        }
      });

      proc.on('error', (error) => {
        reject(error);
      });

      // Timeout
      setTimeout(() => {
        proc.kill();
        reject(new Error(`${command} timeout`));
      }, 60000);
    });
  }

  private classifyTaskType(prompt: string): TaskType {
    // This mirrors Router's classification for consistency
    const patterns = {
      architecture: /\b(design|architect|microservice|system|pattern)\b/i,
      syntax: /\b(fix|syntax|parse|compile|error)\b/i,
      refactor: /\b(refactor|optimize|clean|rewrite)\b/i,
      debug: /\b(debug|bug|crash|stack|investigate)\b/i,
      generate: /\b(create|generate|build|make|write)\b/i,
      test: /\b(test|spec|assert|verify)\b/i,
      docs: /\b(document|comment|explain|describe)\b/i
    } as const;

    for (const [type, regex] of Object.entries(patterns)) {
      if (regex.test(prompt)) {
        return type as TaskType;
      }
    }

    return 'generate'; // Default
  }

  private recordIntent(
    context: ExecutionContext,
    model: string,
    success: boolean,
    executionTime: number
  ): void {
    const intent: IntentHistory = {
      sessionId: context.sessionId,
      query: context.prompt,
      selectedModel: model,
      success,
      timestamp: context.startTime,
      fileContext: context.filePath,
      executionTime
    };

    this.intentHistory.push(intent);

    // Emit event
    this.emit('intentExecuted', intent);

    // Keep only last 1000 intents in memory
    if (this.intentHistory.length > 1000) {
      this.intentHistory.shift();
    }
  }

  getCurrentState(): {
    readonly sessionId: string;
    readonly intentCount: number;
    readonly recentIntents: ReadonlyArray<IntentHistory>;
    readonly projectRoot: string;
  } {
    return {
      sessionId: this.sessionId,
      intentCount: this.intentHistory.length,
      recentIntents: this.intentHistory.slice(-10),
      projectRoot: this.config.projectRoot
    };
  }

  getIntentHistory(): ReadonlyArray<IntentHistory> {
    return [...this.intentHistory];
  }

  getSessionId(): string {
    return this.sessionId;
  }

  async cleanup(): Promise<void> {
    logger.info('Cleaning up orchestrator');
    
    if (this.wsServer) {
      this.wsServer.close();
    }

    this.removeAllListeners();
  }
}
