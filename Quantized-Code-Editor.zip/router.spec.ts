/**
 * Unit tests for Ternary Binary Router
 * Demonstrates decision tree logic and circuit breaker
 */

import { describe, it, expect, beforeEach } from '@jest/globals';
import { FreeModelRouter } from '../src/core/Router';
import { ConfigManager } from '../src/utils/config';
import type { RoutingContext, TaskType } from '../src/core/models';
import { TaskType as TT } from '../src/core/models';

describe('FreeModelRouter', () => {
  let router: FreeModelRouter;
  let config: ReturnType<ConfigManager['getConfig']>;

  beforeEach(() => {
    const configManager = new ConfigManager(process.cwd(), {
      pogDir: '/tmp/test-pog',
      projectRoot: process.cwd(),
      circuitBreakerThreshold: 3,
      circuitBreakerCooldown: 1000 // 1 second for testing
    });
    config = configManager.getConfig();
    router = new FreeModelRouter(config);
  });

  describe('Ternary Decision Tree', () => {
    it('should route simple tasks to lightweight models', async () => {
      const result = await router.route('fix syntax error in hello.ts', 'hello.ts');
      
      expect(result.ok).toBe(true);
      if (result.ok) {
        // Simple task should prefer fast models
        expect(['qwen2.5-coder:14b', 'codellama:13b']).toContain(result.value);
      }
    });

    it('should route complex architectural tasks to specialized models', async () => {
      const complexPrompt = `
        Design a microservices architecture for an e-commerce platform.
        Include API gateway, service discovery, and event-driven communication.
        Consider scalability and fault tolerance.
      `;
      
      const result = await router.route(complexPrompt);
      
      expect(result.ok).toBe(true);
      if (result.ok) {
        // Complex architecture task should use deepseek or phi3
        expect(['deepseek-coder:33b', 'phi3:14b']).toContain(result.value);
      }
    });

    it('should assess complexity based on multiple factors', () => {
      const simpleContext: RoutingContext = {
        prompt: 'add console.log',
        taskType: TT.Generate,
        extension: 'ts',
        historicalPerformance: [],
        availableModels: []
      };

      const complexContext: RoutingContext = {
        prompt: 'design microservices architecture then implement service mesh',
        taskType: TT.Architecture,
        extension: 'ts',
        fileSize: 15000,
        historicalPerformance: [],
        availableModels: []
      };

      // Access private method for testing (would need to expose or use spy)
      // const simpleComplexity = router['assessComplexity'](simpleContext);
      // const complexComplexity = router['assessComplexity'](complexContext);

      // expect(simpleComplexity).toBe(-1); // Simple
      // expect(complexComplexity).toBe(1);  // Complex
    });

    it('should prefer local models over cloud models', async () => {
      const result = await router.route('generate a function');
      
      expect(result.ok).toBe(true);
      if (result.ok) {
        // Should prefer local Ollama models
        const localModels = [
          'qwen2.5-coder:14b',
          'phi3:14b',
          'deepseek-coder:33b',
          'codellama:13b'
        ];
        expect(localModels).toContain(result.value);
      }
    });

    it('should use historical performance to optimize routing', async () => {
      // Simulate successful completions with qwen
      for (let i = 0; i < 5; i++) {
        router.recordPerformance({
          model: 'qwen2.5-coder:14b',
          taskType: TT.Generate,
          extension: 'ts',
          latency: 200,
          success: true,
          timestamp: Date.now(),
          isFree: true
        });
      }

      // Simulate poor performance with codellama
      for (let i = 0; i < 5; i++) {
        router.recordPerformance({
          model: 'codellama:13b',
          taskType: TT.Generate,
          extension: 'ts',
          latency: 5000,
          success: false,
          timestamp: Date.now(),
          isFree: true
        });
      }

      const result = await router.route('generate TypeScript function', 'test.ts');
      
      expect(result.ok).toBe(true);
      if (result.ok) {
        // Should prefer qwen due to better historical performance
        expect(result.value).toBe('qwen2.5-coder:14b');
      }
    });
  });

  describe('Circuit Breaker', () => {
    it('should open circuit after threshold failures', () => {
      const model = 'test-model';

      // Record failures up to threshold
      router.recordFailure(model);
      expect(router.getCircuitState(model)).toBe('CLOSED');

      router.recordFailure(model);
      expect(router.getCircuitState(model)).toBe('CLOSED');

      router.recordFailure(model);
      expect(router.getCircuitState(model)).toBe('OPEN');
    });

    it('should move to half-open after cooldown', async () => {
      const model = 'test-model';

      // Trigger circuit breaker
      router.recordFailure(model);
      router.recordFailure(model);
      router.recordFailure(model);
      
      expect(router.getCircuitState(model)).toBe('OPEN');

      // Wait for cooldown
      await new Promise(resolve => setTimeout(resolve, 1100));

      // Next check should move to HALF_OPEN
      await router.route('test prompt'); // This checks circuit state

      // Note: Would need to expose internal state or use spy to verify HALF_OPEN
    });

    it('should close circuit after successful recovery', () => {
      const model = 'test-model';

      // Open circuit
      router.recordFailure(model);
      router.recordFailure(model);
      router.recordFailure(model);
      expect(router.getCircuitState(model)).toBe('OPEN');

      // Manually set to HALF_OPEN (in production, this happens after cooldown)
      // Would need to expose this or use different testing approach

      // Record success
      router.recordSuccess(model);
      
      // Should close circuit
      // expect(router.getCircuitState(model)).toBe('CLOSED');
    });

    it('should use fallback when circuit is open', async () => {
      const model = 'deepseek-coder:33b';
      const fallback = 'qwen2.5-coder:14b';

      // Open circuit for deepseek
      router.recordFailure(model);
      router.recordFailure(model);
      router.recordFailure(model);

      // Route complex task that would normally use deepseek
      const result = await router.route(
        'design complex microservices architecture',
        'system.ts'
      );

      expect(result.ok).toBe(true);
      if (result.ok) {
        // Should use fallback instead of deepseek
        expect(result.value).toBe(fallback);
      }
    });
  });

  describe('Task Classification', () => {
    it('should classify architecture tasks', async () => {
      const prompts = [
        'design a microservices architecture',
        'create system design for payment service',
        'architect scalable backend pattern'
      ];

      for (const prompt of prompts) {
        const result = await router.route(prompt);
        expect(result.ok).toBe(true);
        // Would verify task type is Architecture
      }
    });

    it('should classify syntax/debug tasks', async () => {
      const prompts = [
        'fix syntax error in line 42',
        'debug stack overflow error',
        'investigate crash in production'
      ];

      for (const prompt of prompts) {
        const result = await router.route(prompt);
        expect(result.ok).toBe(true);
        // Would verify task type is Syntax or Debug
      }
    });

    it('should classify refactor tasks', async () => {
      const prompts = [
        'refactor this function for better readability',
        'optimize database queries',
        'clean up code duplication'
      ];

      for (const prompt of prompts) {
        const result = await router.route(prompt);
        expect(result.ok).toBe(true);
        // Would verify task type is Refactor
      }
    });
  });

  describe('Model Availability', () => {
    it('should return error when no models available', async () => {
      // Would need to mock getAvailableModels to return empty array
      // const result = await router.route('test');
      // expect(result.ok).toBe(false);
      // if (!result.ok) {
      //   expect(result.error.message).toContain('No free models available');
      // }
    });

    it('should prioritize by model priority score', async () => {
      // deepseek has priority 95
      // qwen has priority 90
      // phi3 has priority 80

      const result = await router.route(
        'complex refactoring task requiring deep understanding'
      );

      expect(result.ok).toBe(true);
      if (result.ok) {
        // Should prefer highest priority model for complex task
        expect(result.value).toBe('deepseek-coder:33b');
      }
    });
  });

  describe('Performance Recording', () => {
    it('should record performance metrics', () => {
      const perf = {
        model: 'qwen2.5-coder:14b',
        taskType: TT.Generate,
        extension: 'ts',
        latency: 342,
        success: true,
        timestamp: Date.now(),
        isFree: true,
        tokenCount: 150
      };

      router.recordPerformance(perf);

      // Performance should be persisted to DB
      // Would verify by reading performance DB file
    });

    it('should maintain only recent performance history', () => {
      // Record 11000 performance entries
      for (let i = 0; i < 11000; i++) {
        router.recordPerformance({
          model: 'test-model',
          taskType: TT.Generate,
          extension: 'ts',
          latency: 100,
          success: true,
          timestamp: Date.now(),
          isFree: true
        });
      }

      // Should keep only last 10000
      // Would verify by checking DB size
    });
  });
});

describe('Ternary Tree Navigation', () => {
  it('should navigate to correct leaf based on -1/0/1 decisions', () => {
    const tree = {
      condition: () => -1,
      left: 'model-A',
      center: 'model-B',
      right: 'model-C'
    };

    // Would test tree traversal
    // expect(traverseTree(tree, context)).toBe('model-A');
  });

  it('should handle nested tree structures', () => {
    const tree = {
      condition: () => 0,
      center: {
        condition: () => 1,
        left: 'model-A',
        center: 'model-B',
        right: 'model-C'
      }
    };

    // Should traverse: root(0) -> center -> nested(1) -> right
    // expect(result).toBe('model-C');
  });

  it('should use fallback on missing paths', () => {
    const tree = {
      condition: () => -1,
      // Missing left path
      center: 'model-B',
      right: 'model-C'
    };

    // Should use default fallback
    // expect(result).toBe('qwen2.5-coder:14b');
  });
});
