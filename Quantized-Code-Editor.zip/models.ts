/**
 * Core type definitions for POG-CODER-VIBE
 * All types are immutable by default for safety
 */

export const enum TaskType {
  Architecture = 'architecture',
  Syntax = 'syntax',
  Refactor = 'refactor',
  Debug = 'debug',
  Generate = 'generate',
  Test = 'test',
  Docs = 'docs'
}

export const enum ModelType {
  Local = 'local',
  CloudFree = 'cloud-free'
}

export const enum CircuitState {
  Closed = 'CLOSED',
  Open = 'OPEN',
  HalfOpen = 'HALF_OPEN'
}

export interface ModelPerformance {
  readonly model: string;
  readonly taskType: TaskType;
  readonly extension: string;
  readonly latency: number;
  readonly success: boolean;
  readonly timestamp: number;
  readonly isFree: boolean;
  readonly memoryUsage?: number;
  readonly tokenCount?: number;
}

export interface Lesson {
  readonly id: string;
  readonly embedding: Uint8Array;
  readonly text: string;
  readonly sessionId: string;
  readonly errorType: string;
  readonly createdAt: number;
  readonly metadata?: Record<string, unknown>;
}

export interface IntentHistory {
  readonly sessionId: string;
  readonly query: string;
  readonly selectedModel: string;
  readonly success: boolean;
  readonly timestamp: number;
  readonly fileContext?: string;
  readonly executionTime: number;
  readonly snapshotId?: string;
}

export interface CircuitBreakerState {
  readonly model: string;
  failures: number;
  readonly threshold: number;
  state: CircuitState;
  lastFailure: number;
  readonly cooldownMs: number;
}

export interface FreeModelConfig {
  readonly name: string;
  readonly command: string;
  readonly type: ModelType;
  readonly capabilities: ReadonlyArray<string>;
  readonly fallback?: string;
  readonly maxTokens?: number;
  readonly temperature?: number;
  readonly priority: number; // 0-100, higher = preferred
}

/**
 * Ternary binary decision tree node for routing
 */
export interface TernaryNode {
  readonly condition: (context: RoutingContext) => number; // -1, 0, 1
  readonly left?: TernaryNode | string; // -1 path
  readonly center?: TernaryNode | string; // 0 path
  readonly right?: TernaryNode | string; // 1 path
  readonly modelName?: string; // Leaf node
}

export interface RoutingContext {
  readonly prompt: string;
  readonly taskType: TaskType;
  readonly extension: string;
  readonly fileSize?: number;
  readonly complexity?: number;
  readonly historicalPerformance: ReadonlyArray<ModelPerformance>;
  readonly availableModels: ReadonlyArray<FreeModelConfig>;
}

export type Result<T, E = Error> = 
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

/**
 * Type guard for Result success
 */
export function isOk<T, E>(result: Result<T, E>): result is { ok: true; value: T } {
  return result.ok === true;
}

/**
 * Type guard for Result failure
 */
export function isErr<T, E>(result: Result<T, E>): result is { ok: false; error: E } {
  return result.ok === false;
}

/**
 * Unwrap Result or throw
 */
export function unwrap<T, E>(result: Result<T, E>): T {
  if (isOk(result)) {
    return result.value;
  }
  throw result.error;
}

/**
 * Unwrap Result or return default
 */
export function unwrapOr<T, E>(result: Result<T, E>, defaultValue: T): T {
  return isOk(result) ? result.value : defaultValue;
}

/**
 * Map Result value
 */
export function mapResult<T, U, E>(
  result: Result<T, E>,
  fn: (value: T) => U
): Result<U, E> {
  return isOk(result) ? { ok: true, value: fn(result.value) } : result;
}

/**
 * Chain Result operations
 */
export function andThen<T, U, E>(
  result: Result<T, E>,
  fn: (value: T) => Result<U, E>
): Result<U, E> {
  return isOk(result) ? fn(result.value) : result;
}

export interface LogContext {
  readonly component: string;
  readonly sessionId?: string;
  readonly model?: string;
}

export interface VibeConfig {
  readonly pogDir: string;
  readonly projectRoot: string;
  readonly wsPort: number;
  readonly maxSnapshotAge: number;
  readonly circuitBreakerThreshold: number;
  readonly circuitBreakerCooldown: number;
  readonly embeddingDimensions: number;
  readonly logLevel: 'trace' | 'debug' | 'info' | 'warn' | 'error';
}
